/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

let btnCheck = document.getElementById("validateButton");
let resultText = document.getElementById("resultText");
let downButton = document.getElementById("downButton");

downButton.style.visibility = 'hidden';

btnCheck.addEventListener('click', ()=>{
    let jsonObj = document.getElementById("JSONText").value;
    if(isValidJSON(jsonObj)){
        resultText.innerText = 'JSON Valid !!';
        downButton.style.visibility = 'visible';
    }
    else{
        resultText.innerText = 'JSON inValid :(';
    }
    
});

function isValidJSON(str){
    try{
        if(typeof str != 'string') return false;
        JSON.parse(str);
        return true;
    }
    catch(error){
        return false;
    }
}


